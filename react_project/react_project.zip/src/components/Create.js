
function Create() {
  return (
    <div>
     
    </div>
  );
}

export default Create;